-- ============================
-- 数据库：login_module
-- 描述：登录注册模块数据库
-- ============================

-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS `login_module`
DEFAULT CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE `login_module`;

-- ============================
-- 表：user
-- 描述：用户信息表
-- ============================

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '用户ID，主键',
  `nickname` VARCHAR(50) NOT NULL COMMENT '用户昵称',
  `username` VARCHAR(50) NOT NULL COMMENT '用户账号',
  `gender` VARCHAR(10) DEFAULT NULL COMMENT '性别',
  `description` VARCHAR(255) DEFAULT NULL COMMENT '个人描述',
  `avatar` VARCHAR(255) DEFAULT NULL COMMENT '头像URL',
  `password` VARCHAR(255) NOT NULL COMMENT '密码（加密后）',
  `phoneNumber` VARCHAR(11) DEFAULT NULL COMMENT '手机号码',
  `email` VARCHAR(100) DEFAULT NULL COMMENT '邮箱地址',
  `role` VARCHAR(20) NOT NULL DEFAULT 'USER' COMMENT '用户角色',
  `enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '账号是否启用：1-启用，0-禁用',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`) COMMENT '用户名唯一索引',
  UNIQUE KEY `uk_email` (`email`) COMMENT '邮箱唯一索引',
  UNIQUE KEY `uk_phone` (`phoneNumber`) COMMENT '手机号唯一索引',
  KEY `idx_role` (`role`) COMMENT '角色索引'
) ENGINE=InnoDB 
  DEFAULT CHARSET=utf8mb4 
  COLLATE=utf8mb4_unicode_ci 
  COMMENT='用户信息表';

-- ============================
-- 插入测试数据（可选）
-- ============================

-- 管理员账号（密码：admin123，需要使用BCrypt加密）
-- 注意：实际使用时需要将密码替换为BCrypt加密后的值
INSERT INTO `user` (`nickname`, `username`, `gender`, `description`, `avatar`, `password`, `phoneNumber`, `email`, `role`, `enabled`) 
VALUES 
('系统管理员', 'admin', '保密', '系统管理员账号', NULL, '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '13800138000', 'admin@example.com', 'ADMIN', 1);

-- 普通测试用户（密码：user123）
INSERT INTO `user` (`nickname`, `username`, `gender`, `description`, `avatar`, `password`, `phoneNumber`, `email`, `role`, `enabled`) 
VALUES 
('测试用户', 'testuser', '男', '这是一个测试账号', NULL, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '13900139000', 'test@example.com', 'USER', 1);

