package com.example.login.dto;

import lombok.Data;

@Data
public class Response<T> {

    private T message;


    public static <T> Response<T> success(T message) {
        Response<T> response = new Response<>();
        response.message = message;
        return response;
    }

    public static <T> Response<T> error(T message) {
        Response<T> response = new Response<>();
        response.message = message;
        return response;
    }
}
